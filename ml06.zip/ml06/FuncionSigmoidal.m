function g = FuncionSigmoidal(z)
	g = 1./(1+exp(-z));
end
